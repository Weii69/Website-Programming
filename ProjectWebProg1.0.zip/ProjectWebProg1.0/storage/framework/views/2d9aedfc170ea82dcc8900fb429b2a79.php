<?php $__env->startSection('content'); ?>

<div style="max-width: 800px; margin: 0 auto; padding: 20px; background-color: #fff; box-shadow: 2px 2px 8px rgba(0, 0, 0, 0.1); border-radius: 8px;">
    <h1 style="text-align: center; margin-bottom: 20px;">Edit Recipe</h1>
    <form action="<?php echo e(route('recipe.update', $recipe->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <!-- Nama Resep -->
        <div style="margin-bottom: 15px;">
            <label for="name" style="display: block; font-weight: bold; margin-bottom: 5px;">Nama Resep</label>
            <input type="text" name="name" id="name" value="<?php echo e($recipe->name); ?>" style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 5px;" required>
        </div>

        <!-- Cuisine -->
        <div style="margin-bottom: 15px;">
            <label for="cuisine" style="display: block; font-weight: bold; margin-bottom: 5px;">Cuisine</label>
            <select name="cuisine" id="cuisine" style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 5px;" required>
                <option value="Western" <?php echo e($recipe->cuisine == 'Western' ? 'selected' : ''); ?>>Western</option>
                <option value="Asian" <?php echo e($recipe->cuisine == 'Asian' ? 'selected' : ''); ?>>Asian</option>
                <option value="Middle Eastern" <?php echo e($recipe->cuisine == 'Middle Eastern' ? 'selected' : ''); ?>>Middle Eastern</option>
                <option value="Latin" <?php echo e($recipe->cuisine == 'Latin' ? 'selected' : ''); ?>>Latin</option>
            </select>
        </div>

        <!-- Meal Course -->
        <div style="margin-bottom: 15px;">
            <label for="meal_course" style="display: block; font-weight: bold; margin-bottom: 5px;">Tipe Makanan</label>
            <select name="meal_course" id="meal_course" style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 5px;" required>
                <option value="Appetizer" <?php echo e($recipe->meal_course == 'Appetizer' ? 'selected' : ''); ?>>Appetizer</option>
                <option value="Main Course" <?php echo e($recipe->meal_course == 'Main Course' ? 'selected' : ''); ?>>Main Course</option>
                <option value="Dessert" <?php echo e($recipe->meal_course == 'Dessert' ? 'selected' : ''); ?>>Dessert</option>
            </select>
        </div>

        <!-- Time -->
        <div style="margin-bottom: 15px;">
            <label for="time" style="display: block; font-weight: bold; margin-bottom: 5px;">Waktu Memasak (menit)</label>
            <input type="number" name="time" id="time" value="<?php echo e($recipe->time); ?>" style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 5px;" required>
        </div>

        <!-- Origin -->
        <div style="margin-bottom: 15px;">
            <label for="origin" style="display: block; font-weight: bold; margin-bottom: 5px;">Asal Negara</label>
            <input type="text" name="origin" id="origin" value="<?php echo e($recipe->origin); ?>" style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 5px;" required>
        </div>

        <!-- Difficulty -->
        <div style="margin-bottom: 15px;">
            <label for="difficulty" style="display: block; font-weight: bold; margin-bottom: 5px;">Tingkat Kesulitan</label>
            <select name="difficulty" id="difficulty" style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 5px;" required>
                <option value="Easy" <?php echo e($recipe->difficulty == 'Easy' ? 'selected' : ''); ?>>Easy</option>
                <option value="Medium" <?php echo e($recipe->difficulty == 'Medium' ? 'selected' : ''); ?>>Medium</option>
                <option value="Hard" <?php echo e($recipe->difficulty == 'Hard' ? 'selected' : ''); ?>>Hard</option>
            </select>
        </div>

        <!-- Deskripsi Resep -->
        <div style="margin-bottom: 15px;">
            <label for="description" style="display: block; font-weight: bold; margin-bottom: 5px;">Deskripsi Resep</label>
            <textarea name="description" id="description" rows="4" style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 5px;" required><?php echo e($recipe->description); ?></textarea>
        </div>

        <!-- Gambar Resep -->
        <div style="margin-bottom: 15px;">
            <label for="image" style="display: block; font-weight: bold; margin-bottom: 5px;">Gambar Resep</label>
            <input type="file" name="image" id="image" style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 5px;">
            <p style="font-size: 12px; color: #555; margin-top: 5px;">Biarkan kosong jika tidak ingin mengganti gambar.</p>
        </div>

        <!-- Tombol Back & Submit -->
        <div style="display: flex; gap: 10px; justify-content: left;">
            <a href="<?php echo e(route('recipe.details', ['id' => $recipe->id])); ?>"
               class="btn btn-primary"
               style="padding: 10px 20px; background-color: #007BFF; color: white; text-decoration: none; border-radius: 5px;">
                Kembali
            </a>
            <button type="submit"
                    style="padding: 10px 20px; background-color: #28a745; color: white; border: none; border-radius: 5px; cursor: pointer;">
                Update Resep
            </button>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProjectWebProg - Copy\resources\views/edit.blade.php ENDPATH**/ ?>