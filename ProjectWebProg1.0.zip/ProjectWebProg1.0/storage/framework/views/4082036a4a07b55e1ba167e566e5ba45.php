<?php $__env->startSection('content'); ?>
<div class="container-fluid vh-100 d-flex justify-content-center align-items-center" style="background-image: url('/images/background.jpg'); background-size: cover; background-position: center;">
    <div class="card shadow-lg" style="max-width: 500px; width: 100%; padding: 20px; background-color: white; border-radius: 10px;">
        <div class="card-body text-center">
            <h3 class="card-title mb-4" style="color: #333; font-weight: bold;">Hapus Recipe</h3>
            <p>Apakah Anda yakin ingin menghapus recipe <strong><?php echo e($recipe->name); ?></strong>?</p>
            <form action="<?php echo e(route('delete.recipe', ['id' => $recipe->id])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger me-2">Ya, Hapus</button>
                <a href="<?php echo e(route('allRecipes')); ?>" class="btn btn-secondary">Batal</a>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProjectWebProg - Copy\resources\views/deleteRecipe.blade.php ENDPATH**/ ?>